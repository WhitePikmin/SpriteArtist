﻿namespace SpriteArtist
{
    partial class FRM_Animation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.TBAR_FrameRate = new System.Windows.Forms.TrackBar();
            this.PBX_Animation = new System.Windows.Forms.PictureBox();
            this.TMR_FrameRate = new System.Windows.Forms.Timer(this.components);
            this.FPS_Text = new System.Windows.Forms.Label();
            this.LB_fps_value = new System.Windows.Forms.Label();
            this.FLP_All_Frame = new System.Windows.Forms.FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.TBAR_FrameRate)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBX_Animation)).BeginInit();
            this.SuspendLayout();
            // 
            // TBAR_FrameRate
            // 
            this.TBAR_FrameRate.Location = new System.Drawing.Point(12, 199);
            this.TBAR_FrameRate.Maximum = 15;
            this.TBAR_FrameRate.Minimum = 1;
            this.TBAR_FrameRate.Name = "TBAR_FrameRate";
            this.TBAR_FrameRate.Size = new System.Drawing.Size(213, 45);
            this.TBAR_FrameRate.TabIndex = 0;
            this.TBAR_FrameRate.Value = 1;
            this.TBAR_FrameRate.ValueChanged += new System.EventHandler(this.TBAR_FrameRate_ValueChanged);
            // 
            // PBX_Animation
            // 
            this.PBX_Animation.Location = new System.Drawing.Point(12, 12);
            this.PBX_Animation.Name = "PBX_Animation";
            this.PBX_Animation.Size = new System.Drawing.Size(213, 162);
            this.PBX_Animation.TabIndex = 1;
            this.PBX_Animation.TabStop = false;
            // 
            // TMR_FrameRate
            // 
            this.TMR_FrameRate.Enabled = true;
            this.TMR_FrameRate.Tick += new System.EventHandler(this.TMR_FrameRate_Tick);
            // 
            // FPS_Text
            // 
            this.FPS_Text.AutoSize = true;
            this.FPS_Text.Location = new System.Drawing.Point(30, 238);
            this.FPS_Text.Name = "FPS_Text";
            this.FPS_Text.Size = new System.Drawing.Size(33, 13);
            this.FPS_Text.TabIndex = 2;
            this.FPS_Text.Text = "FPS: ";
            // 
            // LB_fps_value
            // 
            this.LB_fps_value.AutoSize = true;
            this.LB_fps_value.Location = new System.Drawing.Point(69, 238);
            this.LB_fps_value.Name = "LB_fps_value";
            this.LB_fps_value.Size = new System.Drawing.Size(35, 13);
            this.LB_fps_value.TabIndex = 3;
            this.LB_fps_value.Text = "label1";
            // 
            // FLP_All_Frame
            // 
            this.FLP_All_Frame.AutoScroll = true;
            this.FLP_All_Frame.Location = new System.Drawing.Point(235, 12);
            this.FLP_All_Frame.Name = "FLP_All_Frame";
            this.FLP_All_Frame.Size = new System.Drawing.Size(114, 232);
            this.FLP_All_Frame.TabIndex = 4;
            // 
            // FRM_Animation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(361, 263);
            this.Controls.Add(this.FLP_All_Frame);
            this.Controls.Add(this.LB_fps_value);
            this.Controls.Add(this.FPS_Text);
            this.Controls.Add(this.PBX_Animation);
            this.Controls.Add(this.TBAR_FrameRate);
            this.Name = "FRM_Animation";
            this.Text = "FRM_Animation";
            ((System.ComponentModel.ISupportInitialize)(this.TBAR_FrameRate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PBX_Animation)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar TBAR_FrameRate;
        private System.Windows.Forms.PictureBox PBX_Animation;
        private System.Windows.Forms.Timer TMR_FrameRate;
        private System.Windows.Forms.Label FPS_Text;
        private System.Windows.Forms.Label LB_fps_value;
        private System.Windows.Forms.FlowLayoutPanel FLP_All_Frame;
    }
}