﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpriteArtist
{
    public partial class FRM_Animation : Form
    {
        List<Bitmap> _Animation = new List<Bitmap>();
        double _Fps;
        int _Index;
        public FRM_Animation() => InitializeComponent();
        public FRM_Animation(ref List<Bitmap> Animation)
        {
            InitializeComponent();
            _Animation = Animation;
            _Index = 0;
            _Fps = TBAR_FrameRate.Value;
            LB_fps_value.Text = _Fps.ToString();
            CalculateFrameRate();
            Fill_Flow_Layout_Panel();
        }
        private void TMR_FrameRate_Tick(object sender, EventArgs e)
        {
            if (_Index >= _Animation.Count)
                _Index = 0;

            PBX_Animation.InitialImage = null;
            PBX_Animation.Image = (Image)_Animation[_Index];
            PBX_Animation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

            _Index++;
        }
        private void CalculateFrameRate()
        {
            _Fps = TBAR_FrameRate.Value;
            double tick_Value = 1000 / _Fps;
            TMR_FrameRate.Interval = (int)Math.Round(tick_Value, MidpointRounding.AwayFromZero);
        }
        private void TBAR_FrameRate_ValueChanged(object sender, EventArgs e)
        {
            CalculateFrameRate();
            LB_fps_value.Text = _Fps.ToString();
        }
        private void PictureBox_Click(object sender, EventArgs e)
        {
            refreshSelect();
            var pictureBox = sender as PictureBox;
            pictureBox.BackgroundImageLayout = ImageLayout.Center;
            pictureBox.BackColor = Color.DarkGray;
            pictureBox.Padding = new Padding(5, 5, 5, 5);
        }
        private void Fill_Flow_Layout_Panel()
        {
            int frameNum = 0;
            foreach(Bitmap image in _Animation)
            {
                PictureBox newPictureBox = new PictureBox();
                newPictureBox.Name = frameNum.ToString();
                newPictureBox.BackgroundImage = (Image)image;
                newPictureBox.BackgroundImageLayout = ImageLayout.Center;
                newPictureBox.Width = 70;
                newPictureBox.Height = 70;
                newPictureBox.Click += new System.EventHandler(this.PictureBox_Click);
                FLP_All_Frame.Controls.Add(newPictureBox);
                frameNum++;
            }
        }
        private void refreshSelect()
        {
            foreach (PictureBox pbx in FLP_All_Frame.Controls)
            {
                pbx.BackColor = Color.Transparent;
                pbx.Padding = new Padding(0);
            }
        }
    }
}
