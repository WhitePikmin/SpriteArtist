﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpriteArtist
{
    public partial class FRM_Main
    {
        List<Bitmap> AnimationFrame = new List<Bitmap>();
        double _Fps = 1;
        int _Index = 0;
       
        private void TMR_FrameRate_Tick(object sender, EventArgs e)
        {
            if (_Index >= AnimationFrame.Count)
                _Index = 0;

            PBX_Animation.InitialImage = null;
            if(AnimationFrame.Count != 0)
                PBX_Animation.Image = (Image)AnimationFrame[_Index];
            PBX_Animation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;

            _Index++;
        }
        private void CalculateFrameRate()
        {
            _Fps = TBAR_FrameRate.Value;
            double tick_Value = 1000 / _Fps;
            TMR_FrameRate.Interval = (int)Math.Round(tick_Value, MidpointRounding.AwayFromZero);
        }
        private void TBAR_FrameRate_ValueChanged(object sender, EventArgs e)
        {
            CalculateFrameRate();
            LB_fps_value.Text = _Fps.ToString();
        }
        private void PictureBox_Click(object sender, EventArgs e)
        {
            
            var pictureBox = sender as PictureBox;
            pictureBox.BackColor = Color.DarkGray;
            pictureBox.Padding = new Padding(5, 5, 5, 5);
        }
        private void PictureBox_DoubleClick(object sender, EventArgs e)
        {
            PictureBox pbx = (PictureBox)sender;
            Sprite = (Bitmap)pbx.BackgroundImage;
        }
        private void Fill_Flow_Layout_Panel()
        {
            int frameNum = 0;
            foreach (Bitmap image in AnimationFrame)
            {
                PictureBox newPictureBox = new PictureBox();
                newPictureBox.Name = frameNum.ToString();
                newPictureBox.BackgroundImage = (Image)image;
                newPictureBox.BackgroundImageLayout = ImageLayout.Stretch;
                newPictureBox.Width = 80;
                newPictureBox.Height = 80;
                newPictureBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.p_MouseDown);
                FLP_All_Frame.Controls.Add(newPictureBox);
                frameNum++;
            }
        }
        private void RefreshSelect()
        {
            AnimationFrame.Clear();
            foreach (PictureBox pbx in FLP_All_Frame.Controls)
            {
                pbx.BackColor = Color.Transparent;
                pbx.Padding = new Padding(0);
                Bitmap bmp = new Bitmap(pbx.BackgroundImage);
                AnimationFrame.Add(bmp);
            }
        }
        private void BTN_Add_Frame_Click(object sender, EventArgs e)
        {
            FLP_All_Frame.Controls.Clear();
            AddBitmapToAnimation();
            Fill_Flow_Layout_Panel();
        }
        private void AddBitmapToAnimation() => AnimationFrame.Add(new Bitmap(Sprite));
        private void BTN_Start_Click(object sender, EventArgs e)
        {
            CalculateFrameRate();
            TMR_FrameRate.Enabled = true;
        }
        private void BTN_Stop_Click(object sender, EventArgs e) => TMR_FrameRate.Enabled = false;        
        private void activerAnimationToolStripMenuItem_Click(object sender, EventArgs e) => PNL_Animation.Visible = !PNL_Animation.Visible;
        private void FLP_All_Frame_DragEnter(object sender, DragEventArgs e) => e.Effect = DragDropEffects.All;
        private void FLP_All_Frame_DragDrop(object sender, DragEventArgs e)
        {
            PictureBox picture = (PictureBox)e.Data.GetData(typeof(PictureBox));
            FlowLayoutPanel _source = (FlowLayoutPanel)picture.Parent;
            FlowLayoutPanel _destination = (FlowLayoutPanel)sender;
            

            Point p = _destination.PointToClient(new Point(e.X, e.Y));
            var item = _destination.GetChildAtPoint(p);
            int index = _destination.Controls.GetChildIndex(item, false);
            _destination.Controls.SetChildIndex(picture, index);
            _destination.Invalidate();         
        }
        private void p_MouseDown(object sender, MouseEventArgs e)
        {
            PictureBox p = (PictureBox)sender;
            p.BackColor = Color.DarkGray;
            p.Padding = new Padding(5, 5, 5, 5);
            p.DoDragDrop(p, DragDropEffects.All);
            RefreshSelect();
        }
       
        private void BTN_Supp_Frame_Click(object sender, EventArgs e)
        {

        }
    }
}